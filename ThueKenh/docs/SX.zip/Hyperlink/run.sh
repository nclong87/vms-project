java -Dapplication.defaultlaf=system -cp ../SX.jar HyperlinkReadSample
java -Dapplication.defaultlaf=system -cp ../SX.jar HyperlinkWriteSample