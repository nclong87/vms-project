java -Dapplication.defaultlaf=system -cp ../SX.jar FormulaSample
java -Dapplication.defaultlaf=system -cp ../SX.jar FormulaTestSample