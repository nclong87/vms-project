java -Dapplication.defaultlaf=system -cp ../SX.jar ChartPreserveSample
java -Dapplication.defaultlaf=system -cp ../SX.jar ChartSample
java -Dapplication.defaultlaf=system -cp ../SX.jar ChartsEditSample
java -Dapplication.defaultlaf=system -cp ../SX.jar ChartSheetSample